package com.zzteck.cardect.util;

public class MessageUtils {

	public static String message = "" ;
}
