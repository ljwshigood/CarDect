package com.zzteck.cardect.impl;

/**
 * Created by Jianwei on 2018/6/10.
 */

public interface IPrintListener {

    public void printString(String print) ;
}
