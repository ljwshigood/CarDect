package com.zzteck.cardect.btprinter.bt;

/**
 * Created by yefeng on 6/1/15.
 * github:yefengfreedom
 * <p/>
 * blue tooth receiver message type
 */
public class BtMsgType {
    public static final int BLUETOOTH_STATUS_CHANGE = 1;
}
