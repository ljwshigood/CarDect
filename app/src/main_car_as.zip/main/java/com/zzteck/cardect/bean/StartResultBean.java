package com.zzteck.cardect.bean;

public class StartResultBean {

	private int message ;

	public int getMessage() {
		return message;
	}

	public void setMessage(int message) {
		this.message = message;
	}
}
