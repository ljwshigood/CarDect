package com.zzteck.cardect.btprinter.print;

/**
 * Created by yefeng on 6/1/15.
 * github:yefengfreedom
 * <p/>
 * printer eventbus message type
 */
public class PrinterMsgType {
    public static final int MESSAGE_STATE_CHANGE = 1;
    public static final int MESSAGE_TOAST = 2;
}
