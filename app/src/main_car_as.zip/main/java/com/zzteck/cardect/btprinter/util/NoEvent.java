package com.zzteck.cardect.btprinter.util;

/**
 * Created by yefeng on 7/1/15.
 * github:yefengfreedom
 */
public class NoEvent {
}
